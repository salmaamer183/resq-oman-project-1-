# RESQ OMAN — Full Project

AI-assisted national search & rescue command platform. This repo contains
both halves of the project so you can edit and deploy them together or
separately.

```
resq-oman/
├── frontend/          static bilingual (EN/AR) command-center UI
│   ├── index.html
│   ├── css/styles.css
│   └── js/app.js
└── backend/           FastAPI + PostgreSQL API
    ├── app/            (models, schemas, routes, auth, ...)
    ├── requirements.txt
    └── README.md        ← full backend docs (auth flow, endpoints, security)
```

## Editing the frontend

Plain HTML/CSS/JS — no build step, no framework, no `node_modules`. Open
`frontend/index.html` directly in a browser to preview it, or edit
`frontend/css/styles.css` and `frontend/js/app.js` in any editor and
refresh the page to see changes.

## Editing the backend

See **`backend/README.md`** for full setup, environment variables, the
authentication flow, and the API reference. Quick start (no Docker):

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env: set a real SECRET_KEY and point DATABASE_URL at a Postgres
# instance you already have running (locally installed, or a managed one)

uvicorn app.main:app --reload
```

API docs: http://localhost:8000/api/docs

## Deploying

**Frontend** (static files, no server logic needed):
- Upload the contents of `frontend/` to any static host — Vercel, Netlify,
  Cloudflare Pages, GitHub Pages, S3+CloudFront, or a plain web server.
  No build command required; the site root is `frontend/`.

**Backend** (needs a running Python process + a Postgres database):
- Any host that runs a Python app (a VPS, Render, Railway, Fly.io,
  PythonAnywhere, etc.): install `backend/requirements.txt` and run
  `uvicorn app.main:app --host 0.0.0.0 --port <port>` behind your usual
  process manager / reverse proxy.
- Point `DATABASE_URL` in `.env` at your Postgres instance (self-hosted or
  managed — e.g. Supabase, Neon, RDS, etc.).
- Run migrations with Alembic (see `backend/README.md`) before first use.

Either way, once the backend is live, update the frontend's data layer
(currently in-memory mock data in `js/app.js`) to call your deployed
backend's URL instead — that wiring isn't done yet (see "What's still
mocked" in `backend/README.md`).

## Current state

- **Frontend**: fully built prototype — dashboard, live map, AI detection,
  6 AI agents, missions with command/operations tracking, missing-person
  intake form, personnel, drones, alerts, analytics. Bilingual EN/AR with
  full RTL switch. Runs entirely on in-memory mock data — no network calls.
- **Backend**: real FastAPI + PostgreSQL API with JWT auth, roles, and CRUD
  for missions/personnel/drones/alerts/detections — not yet wired to the
  frontend (they currently run independently).

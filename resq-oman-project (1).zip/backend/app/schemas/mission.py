from pydantic import BaseModel, ConfigDict

from app.models.mission import MissionPriority, MissionStatus


class MissionCreate(BaseModel):
    incident_type: str
    location: str
    lat: float | None = None
    lng: float | None = None
    priority: MissionPriority = MissionPriority.MEDIUM
    assigned_team_id: str | None = None
    assigned_ambulance_id: str | None = None
    assigned_helicopter_id: str | None = None
    assigned_drone_id: str | None = None
    eta_minutes: int | None = None
    notes: str | None = None


class MissionUpdate(BaseModel):
    status: MissionStatus | None = None
    progress_pct: int | None = None
    eta_minutes: int | None = None
    assigned_team_id: str | None = None
    assigned_ambulance_id: str | None = None
    assigned_helicopter_id: str | None = None
    assigned_drone_id: str | None = None
    notes: str | None = None


class MissionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    reference_code: str
    incident_type: str
    location: str
    priority: MissionPriority
    status: MissionStatus
    progress_pct: int
    eta_minutes: int | None
    assigned_team_id: str | None
    assigned_ambulance_id: str | None
    assigned_helicopter_id: str | None
    assigned_drone_id: str | None

from pydantic import BaseModel, ConfigDict

from app.models.drone import CameraStatus


class DroneTelemetryUpdate(BaseModel):
    battery_pct: int | None = None
    speed_kmh: float | None = None
    altitude_m: float | None = None
    lat: float | None = None
    lng: float | None = None
    signal_strength: int | None = None
    camera_status: CameraStatus | None = None
    assigned_mission_id: str | None = None


class DroneOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    call_sign: str
    battery_pct: int
    speed_kmh: float
    altitude_m: float
    lat: float | None
    lng: float | None
    signal_strength: int
    camera_status: CameraStatus
    assigned_mission_id: str | None

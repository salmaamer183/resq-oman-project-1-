from pydantic import BaseModel, ConfigDict

from app.models.alert import AlertType


class AlertCreate(BaseModel):
    type: AlertType
    title: str
    message: str
    related_mission_id: str | None = None


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    type: AlertType
    title: str
    message: str
    related_mission_id: str | None
    is_read: bool

from pydantic import BaseModel, ConfigDict

from app.models.team import PersonnelCategory, Availability


class PersonnelCreate(BaseModel):
    name: str
    rank: str | None = None
    category: PersonnelCategory
    team_id: str | None = None
    skills: list[str] = []
    current_location: str | None = None
    availability: Availability = Availability.AVAILABLE


class PersonnelUpdate(BaseModel):
    rank: str | None = None
    skills: list[str] | None = None
    current_location: str | None = None
    availability: Availability | None = None


class PersonnelOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    rank: str | None
    category: PersonnelCategory
    skills: list[str]
    current_location: str | None
    availability: Availability
    missions_completed: int

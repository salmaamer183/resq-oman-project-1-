from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, PaginationParams
from app.db.session import get_db
from app.models.detection import AIDetection
from app.models.user import User
from app.schemas.common import Page
from pydantic import BaseModel, ConfigDict

router = APIRouter(prefix="/detections", tags=["AI Detections"])


class DetectionCreate(BaseModel):
    source: str
    object_label: str
    confidence_pct: int
    bounding_box: str | None = None
    related_mission_id: str | None = None
    related_drone_id: str | None = None


class DetectionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    source: str
    object_label: str
    confidence_pct: int
    bounding_box: str | None
    related_mission_id: str | None
    related_drone_id: str | None


@router.get("", response_model=Page[DetectionOut])
def list_detections(
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(AIDetection).order_by(AIDetection.created_at.desc())
    total = query.count()
    items = query.offset(pagination.offset).limit(pagination.page_size).all()
    return Page(
        items=items, total=total, page=pagination.page, page_size=pagination.page_size,
        pages=(total + pagination.page_size - 1) // pagination.page_size,
    )


@router.post("", response_model=DetectionOut, status_code=201)
def create_detection(payload: DetectionCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    """
    Called by the Vision Agent / inference service whenever a new object
    is detected in an uploaded image, video frame, or live drone feed.
    """
    detection = AIDetection(**payload.model_dump())
    db.add(detection)
    db.commit()
    db.refresh(detection)
    return detection

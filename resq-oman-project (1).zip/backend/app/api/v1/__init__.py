from fastapi import APIRouter

from app.api.v1 import auth, users, missions, personnel, drones, alerts, detections

api_router = APIRouter()
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(missions.router)
api_router.include_router(personnel.router)
api_router.include_router(drones.router)
api_router.include_router(alerts.router)
api_router.include_router(detections.router)

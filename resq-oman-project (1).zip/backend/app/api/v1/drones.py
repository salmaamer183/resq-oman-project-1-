from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles, PaginationParams
from app.db.session import get_db
from app.models.drone import Drone
from app.models.user import User, UserRole
from app.schemas.common import Page
from app.schemas.drone import DroneOut, DroneTelemetryUpdate

router = APIRouter(prefix="/drones", tags=["Drones"])


@router.get("", response_model=Page[DroneOut])
def list_drones(pagination: PaginationParams = Depends(), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = db.query(Drone)
    total = query.count()
    items = query.offset(pagination.offset).limit(pagination.page_size).all()
    return Page(
        items=items, total=total, page=pagination.page, page_size=pagination.page_size,
        pages=(total + pagination.page_size - 1) // pagination.page_size,
    )


@router.patch(
    "/{drone_id}/telemetry",
    response_model=DroneOut,
    dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN, UserRole.OPERATOR))],
)
def update_telemetry(drone_id: str, payload: DroneTelemetryUpdate, db: Session = Depends(get_db)):
    """
    Intended to be called by the drone's onboard telemetry uplink /
    ground control station on a short interval (e.g. every 1-2s).
    """
    drone = db.get(Drone, drone_id)
    if not drone:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Drone not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(drone, field, value)

    db.commit()
    db.refresh(drone)
    return drone

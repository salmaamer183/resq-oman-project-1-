from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles, PaginationParams
from app.db.session import get_db
from app.models.user import User, UserRole
from app.schemas.common import Page
from app.schemas.user import UserOut

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me", response_model=UserOut)
def read_current_user(current_user: User = Depends(get_current_user)):
    return current_user


@router.get("", response_model=Page[UserOut], dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN))])
def list_users(pagination: PaginationParams = Depends(), db: Session = Depends(get_db)):
    query = db.query(User)
    total = query.count()
    items = query.offset(pagination.offset).limit(pagination.page_size).all()
    return Page(
        items=items,
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
        pages=(total + pagination.page_size - 1) // pagination.page_size,
    )

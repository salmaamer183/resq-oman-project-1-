from fastapi import APIRouter, Depends, HTTPException, status

from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles, PaginationParams
from app.db.session import get_db
from app.models.team import Personnel, PersonnelCategory
from app.models.user import User, UserRole
from app.schemas.common import Page
from app.schemas.team import PersonnelCreate, PersonnelUpdate, PersonnelOut

router = APIRouter(prefix="/personnel", tags=["Personnel"])


@router.get("", response_model=Page[PersonnelOut])
def list_personnel(
    pagination: PaginationParams = Depends(),
    category: PersonnelCategory | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Personnel)
    if category:
        query = query.filter(Personnel.category == category)

    total = query.count()
    items = query.offset(pagination.offset).limit(pagination.page_size).all()
    return Page(
        items=items, total=total, page=pagination.page, page_size=pagination.page_size,
        pages=(total + pagination.page_size - 1) // pagination.page_size,
    )


@router.post(
    "", response_model=PersonnelOut, status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN))],
)
def create_personnel(payload: PersonnelCreate, db: Session = Depends(get_db)):
    person = Personnel(**payload.model_dump())
    db.add(person)
    db.commit()
    db.refresh(person)
    return person


@router.patch("/{person_id}", response_model=PersonnelOut)
def update_personnel(person_id: str, payload: PersonnelUpdate, db: Session = Depends(get_db)):
    person = db.get(Personnel, person_id)
    if not person:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Personnel record not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(person, field, value)
    db.commit()
    db.refresh(person)
    return person

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles, PaginationParams
from app.db.session import get_db
from app.models.alert import Alert, AlertType
from app.models.user import User, UserRole
from app.schemas.alert import AlertCreate, AlertOut
from app.schemas.common import Page

router = APIRouter(prefix="/alerts", tags=["Alerts"])


@router.get("", response_model=Page[AlertOut])
def list_alerts(
    pagination: PaginationParams = Depends(),
    type_filter: AlertType | None = None,
    unread_only: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Alert)
    if type_filter:
        query = query.filter(Alert.type == type_filter)
    if unread_only:
        query = query.filter(Alert.is_read.is_(False))

    total = query.count()
    items = query.order_by(Alert.created_at.desc()).offset(pagination.offset).limit(pagination.page_size).all()
    return Page(
        items=items, total=total, page=pagination.page, page_size=pagination.page_size,
        pages=(total + pagination.page_size - 1) // pagination.page_size,
    )


@router.post(
    "", response_model=AlertOut, status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN, UserRole.OPERATOR))],
)
def create_alert(payload: AlertCreate, db: Session = Depends(get_db)):
    alert = Alert(**payload.model_dump())
    db.add(alert)
    db.commit()
    db.refresh(alert)
    return alert


@router.patch("/{alert_id}/read", response_model=AlertOut)
def mark_as_read(alert_id: str, db: Session = Depends(get_db)):
    alert = db.get(Alert, alert_id)
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")
    alert.is_read = True
    db.commit()
    db.refresh(alert)
    return alert

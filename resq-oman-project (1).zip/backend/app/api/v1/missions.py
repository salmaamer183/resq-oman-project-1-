import random
import string

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles, PaginationParams
from app.db.session import get_db
from app.models.mission import Mission, MissionStatus, MissionPriority
from app.models.user import User, UserRole
from app.schemas.common import Page
from app.schemas.mission import MissionCreate, MissionUpdate, MissionOut

router = APIRouter(prefix="/missions", tags=["Missions"])


def _generate_reference_code() -> str:
    return "MSN-" + "".join(random.choices(string.digits, k=3))


@router.get("", response_model=Page[MissionOut])
def list_missions(
    pagination: PaginationParams = Depends(),
    status_filter: MissionStatus | None = Query(None, alias="status"),
    priority: MissionPriority | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Mission)
    if status_filter:
        query = query.filter(Mission.status == status_filter)
    if priority:
        query = query.filter(Mission.priority == priority)

    total = query.count()
    items = (
        query.order_by(Mission.created_at.desc())
        .offset(pagination.offset)
        .limit(pagination.page_size)
        .all()
    )
    return Page(
        items=items,
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
        pages=(total + pagination.page_size - 1) // pagination.page_size,
    )


@router.get("/{mission_id}", response_model=MissionOut)
def get_mission(mission_id: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    mission = db.get(Mission, mission_id)
    if not mission:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Mission not found")
    return mission


@router.post(
    "",
    response_model=MissionOut,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN, UserRole.OPERATOR))],
)
def create_mission(payload: MissionCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    mission = Mission(reference_code=_generate_reference_code(), created_by_id=current_user.id, **payload.model_dump())
    db.add(mission)
    db.commit()
    db.refresh(mission)
    return mission


@router.patch(
    "/{mission_id}",
    response_model=MissionOut,
    dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN, UserRole.OPERATOR))],
)
def update_mission(mission_id: str, payload: MissionUpdate, db: Session = Depends(get_db)):
    mission = db.get(Mission, mission_id)
    if not mission:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Mission not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(mission, field, value)

    db.commit()
    db.refresh(mission)
    return mission


@router.delete(
    "/{mission_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(require_roles(UserRole.COMMANDER, UserRole.ADMIN))],
)
def delete_mission(mission_id: str, db: Session = Depends(get_db)):
    mission = db.get(Mission, mission_id)
    if not mission:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Mission not found")
    db.delete(mission)
    db.commit()

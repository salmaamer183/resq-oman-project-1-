"""
Seed the database with demo data matching the frontend prototype
(resq-oman.html) so the two can be connected end-to-end.

Run with:  python -m app.seed
"""

from app.core.security import hash_password
from app.db.session import SessionLocal, engine
from app.db.base_class import Base
import app.models  # noqa: F401
from app.models.user import User, UserRole
from app.models.team import Team, Personnel, PersonnelCategory, Availability
from app.models.vehicle import Vehicle, VehicleType, VehicleStatus
from app.models.drone import Drone, CameraStatus
from app.models.mission import Mission, MissionPriority, MissionStatus


def run():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(User).first():
            print("Database already seeded — skipping.")
            return

        # --- Users (one per role, matching the login screen) ---
        demo_users = [
            ("Commander Al Habsi", "commander@resq.om", UserRole.COMMANDER),
            ("Admin Al Balushi", "admin@resq.om", UserRole.ADMIN),
            ("Operator Al Kindi", "operator@resq.om", UserRole.OPERATOR),
            ("Volunteer Al Rawahi", "volunteer@resq.om", UserRole.VOLUNTEER),
            ("Medic Al Zadjali", "medic@resq.om", UserRole.MEDIC),
        ]
        for name, email, role in demo_users:
            db.add(User(
                full_name=name, email=email, role=role,
                hashed_password=hash_password("ChangeMe123!"),
                is_active=True, is_email_verified=True,
            ))

        # --- Teams ---
        alpha = Team(name="Alpha Rescue", category=PersonnelCategory.RESCUE, base_location="Nizwa Base")
        bravo = Team(name="Bravo Team", category=PersonnelCategory.RESCUE, base_location="Ash Sharqiyah")
        db.add_all([alpha, bravo])
        db.flush()

        db.add_all([
            Personnel(name="Yousuf Al Balushi", rank="Team Leader", category=PersonnelCategory.RESCUE,
                      team_id=alpha.id, skills=["Rope Rescue", "First Aid", "Navigation"],
                      current_location="Jebel Akhdar", availability=Availability.ON_MISSION, missions_completed=47),
            Personnel(name="Dr. Aisha Al Zadjali", rank="ER Physician", category=PersonnelCategory.MEDICAL,
                      skills=["Triage", "Trauma Surgery"], current_location="Sultan Qaboos Hospital",
                      availability=Availability.AVAILABLE, missions_completed=8),
        ])

        # --- Vehicles ---
        db.add_all([
            Vehicle(call_sign="A-05", type=VehicleType.AMBULANCE, status=VehicleStatus.DEPLOYED, base_location="Nizwa"),
            Vehicle(call_sign="H-02", type=VehicleType.HELICOPTER, status=VehicleStatus.DEPLOYED, base_location="Muscat"),
        ])

        # --- Drones ---
        db.add_all([
            Drone(call_sign="D-01", battery_pct=78, speed_kmh=42, altitude_m=120, signal_strength=4, camera_status=CameraStatus.OK),
            Drone(call_sign="D-03", battery_pct=91, speed_kmh=55, altitude_m=180, signal_strength=5, camera_status=CameraStatus.OK),
        ])

        # --- Missions ---
        db.add(Mission(
            reference_code="MSN-091", incident_type="Missing Hiker", location="Jebel Akhdar, Al Dakhiliyah",
            priority=MissionPriority.CRITICAL, status=MissionStatus.SEARCH_ACTIVE, progress_pct=64, eta_minutes=42,
        ))

        db.commit()
        print("Seed complete. Demo login: commander@resq.om / ChangeMe123!")
    finally:
        db.close()


if __name__ == "__main__":
    run()

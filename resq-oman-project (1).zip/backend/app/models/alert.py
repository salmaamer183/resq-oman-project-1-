import enum

from sqlalchemy import String, Enum, Boolean, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class AlertType(str, enum.Enum):
    SOS = "sos"
    WEATHER = "weather"
    AI = "ai"
    MISSION = "mission"
    TEAM = "team"
    HIGH_PRIORITY = "high"


class Alert(Base, TimestampMixin):
    __tablename__ = "alerts"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    type: Mapped[AlertType] = mapped_column(Enum(AlertType, values_callable=lambda o: [e.value for e in o]), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    related_mission_id: Mapped[str | None] = mapped_column(ForeignKey("missions.id"), nullable=True)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)

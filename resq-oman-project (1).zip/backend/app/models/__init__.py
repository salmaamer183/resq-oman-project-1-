"""
Import every model here so that Base.metadata.create_all() (and Alembic's
autogenerate) can discover all tables from a single entrypoint.
"""

from app.models.user import User, UserRole  # noqa: F401
from app.models.team import Team, Personnel, PersonnelCategory, Availability  # noqa: F401
from app.models.vehicle import Vehicle, VehicleType, VehicleStatus  # noqa: F401
from app.models.drone import Drone, CameraStatus  # noqa: F401
from app.models.mission import Mission, MissionPriority, MissionStatus  # noqa: F401
from app.models.alert import Alert, AlertType  # noqa: F401
from app.models.detection import AIDetection  # noqa: F401
from app.models.report import MissionReport, MedicalRecord  # noqa: F401
from app.models.activity_log import ActivityLog  # noqa: F401

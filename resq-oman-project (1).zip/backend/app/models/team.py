import enum

from sqlalchemy import String, Enum, Integer, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class PersonnelCategory(str, enum.Enum):
    RESCUE = "rescue"
    VOLUNTEER = "volunteer"
    POLICE = "police"
    CIVIL_DEFENSE = "civil"
    MEDICAL = "medical"


class Availability(str, enum.Enum):
    AVAILABLE = "available"
    ON_MISSION = "onmission"
    OFF_DUTY = "offduty"


class Team(Base, TimestampMixin):
    __tablename__ = "teams"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    category: Mapped[PersonnelCategory] = mapped_column(Enum(PersonnelCategory, values_callable=lambda o: [e.value for e in o]), nullable=False)
    base_location: Mapped[str] = mapped_column(String(150), nullable=True)


class Personnel(Base, TimestampMixin):
    __tablename__ = "personnel"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    team_id: Mapped[str | None] = mapped_column(ForeignKey("teams.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    rank: Mapped[str] = mapped_column(String(80), nullable=True)
    category: Mapped[PersonnelCategory] = mapped_column(Enum(PersonnelCategory, values_callable=lambda o: [e.value for e in o]), nullable=False)
    skills: Mapped[list] = mapped_column(JSON, default=list)
    current_location: Mapped[str] = mapped_column(String(150), nullable=True)
    availability: Mapped[Availability] = mapped_column(Enum(Availability, values_callable=lambda o: [e.value for e in o]), default=Availability.AVAILABLE)
    missions_completed: Mapped[int] = mapped_column(Integer, default=0)

import enum

from sqlalchemy import String, Enum, Integer, Float, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class MissionPriority(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"


class MissionStatus(str, enum.Enum):
    DISPATCHED = "dispatched"
    EN_ROUTE = "en_route"
    ON_SCENE = "on_scene"
    SEARCH_ACTIVE = "search_active"
    SUBJECT_LOCATED = "subject_located"
    EXTRACTION = "extraction"
    COMPLETED = "completed"


class Mission(Base, TimestampMixin):
    __tablename__ = "missions"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    reference_code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    incident_type: Mapped[str] = mapped_column(String(100), nullable=False)
    location: Mapped[str] = mapped_column(String(200), nullable=False)
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lng: Mapped[float | None] = mapped_column(Float, nullable=True)

    priority: Mapped[MissionPriority] = mapped_column(Enum(MissionPriority, values_callable=lambda o: [e.value for e in o]), default=MissionPriority.MEDIUM)
    status: Mapped[MissionStatus] = mapped_column(Enum(MissionStatus, values_callable=lambda o: [e.value for e in o]), default=MissionStatus.DISPATCHED)
    progress_pct: Mapped[int] = mapped_column(Integer, default=0)
    eta_minutes: Mapped[int | None] = mapped_column(Integer, nullable=True)

    assigned_team_id: Mapped[str | None] = mapped_column(ForeignKey("teams.id"), nullable=True)
    assigned_ambulance_id: Mapped[str | None] = mapped_column(ForeignKey("vehicles.id"), nullable=True)
    assigned_helicopter_id: Mapped[str | None] = mapped_column(ForeignKey("vehicles.id"), nullable=True)
    assigned_drone_id: Mapped[str | None] = mapped_column(ForeignKey("drones.id"), nullable=True)

    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)

import enum

from sqlalchemy import String, Enum, Float
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class VehicleType(str, enum.Enum):
    AMBULANCE = "ambulance"
    HELICOPTER = "helicopter"


class VehicleStatus(str, enum.Enum):
    AVAILABLE = "available"
    DEPLOYED = "deployed"
    MAINTENANCE = "maintenance"


class Vehicle(Base, TimestampMixin):
    __tablename__ = "vehicles"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    call_sign: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    type: Mapped[VehicleType] = mapped_column(Enum(VehicleType, values_callable=lambda o: [e.value for e in o]), nullable=False)
    status: Mapped[VehicleStatus] = mapped_column(Enum(VehicleStatus, values_callable=lambda o: [e.value for e in o]), default=VehicleStatus.AVAILABLE)
    base_location: Mapped[str] = mapped_column(String(150), nullable=True)
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lng: Mapped[float | None] = mapped_column(Float, nullable=True)

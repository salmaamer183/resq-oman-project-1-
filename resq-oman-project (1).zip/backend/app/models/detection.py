from sqlalchemy import String, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class AIDetection(Base, TimestampMixin):
    __tablename__ = "ai_detections"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    source: Mapped[str] = mapped_column(String(150), nullable=False)  # e.g. "Drone D-03" or "Upload — IMG_2291"
    object_label: Mapped[str] = mapped_column(String(100), nullable=False)
    confidence_pct: Mapped[int] = mapped_column(Integer, nullable=False)
    bounding_box: Mapped[str | None] = mapped_column(String(100), nullable=True)  # "x,y,w,h" normalized
    related_mission_id: Mapped[str | None] = mapped_column(ForeignKey("missions.id"), nullable=True)
    related_drone_id: Mapped[str | None] = mapped_column(ForeignKey("drones.id"), nullable=True)

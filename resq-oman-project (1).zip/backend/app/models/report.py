from sqlalchemy import String, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class MissionReport(Base, TimestampMixin):
    __tablename__ = "mission_reports"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), nullable=False)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    outcome: Mapped[str] = mapped_column(String(100), nullable=True)
    authored_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class MedicalRecord(Base, TimestampMixin):
    __tablename__ = "medical_records"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    mission_id: Mapped[str] = mapped_column(ForeignKey("missions.id"), nullable=False)
    triage_level: Mapped[str] = mapped_column(String(50), nullable=True)
    condition_notes: Mapped[str] = mapped_column(Text, nullable=True)
    recorded_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)

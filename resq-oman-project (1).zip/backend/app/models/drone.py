import enum

from sqlalchemy import String, Enum, Integer, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base_class import Base, TimestampMixin, new_uuid


class CameraStatus(str, enum.Enum):
    OK = "ok"
    WARN = "warn"
    OFFLINE = "offline"


class Drone(Base, TimestampMixin):
    __tablename__ = "drones"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=new_uuid)
    call_sign: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)

    battery_pct: Mapped[int] = mapped_column(Integer, default=100)
    speed_kmh: Mapped[float] = mapped_column(Float, default=0)
    altitude_m: Mapped[float] = mapped_column(Float, default=0)
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lng: Mapped[float | None] = mapped_column(Float, nullable=True)
    signal_strength: Mapped[int] = mapped_column(Integer, default=5)  # 0-5 bars
    camera_status: Mapped[CameraStatus] = mapped_column(Enum(CameraStatus, values_callable=lambda o: [e.value for e in o]), default=CameraStatus.OK)

    assigned_mission_id: Mapped[str | None] = mapped_column(ForeignKey("missions.id"), nullable=True)

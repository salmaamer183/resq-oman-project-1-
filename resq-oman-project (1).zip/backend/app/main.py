from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi.errors import RateLimitExceeded
from slowapi import _rate_limit_exceeded_handler

from app.core.config import settings
from app.core.logging_config import setup_logging, logger
from app.db.session import engine
from app.db.base_class import Base
from app.middleware.rate_limit import limiter
from app.middleware.error_handler import register_error_handlers

# Import models so they register on Base.metadata before create_all() runs.
import app.models  # noqa: F401

from app.api.v1 import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    logger.info("Starting %s (%s)", settings.APP_NAME, settings.ENVIRONMENT)
    # MVP convenience: create tables directly from models.
    # For production, replace this with Alembic migrations:
    #   alembic upgrade head
    Base.metadata.create_all(bind=engine)
    yield
    logger.info("Shutting down %s", settings.APP_NAME)


app = FastAPI(
    title=settings.APP_NAME,
    description=(
        "REST API for RESQ OMAN — an AI-assisted national search & rescue "
        "command platform. Provides authentication, mission management, "
        "personnel & fleet tracking, AI detection ingestion, and alerting."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

# --- Rate limiting ---
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# --- CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Global error handling ---
register_error_handlers(app)

# --- Routers ---
app.include_router(api_router, prefix=settings.API_V1_PREFIX)


@app.get("/api/health", tags=["System"])
def health_check():
    return {"status": "ok", "app": settings.APP_NAME, "environment": settings.ENVIRONMENT}


@app.get("/", tags=["System"])
def root(request: Request):
    return {
        "message": "RESQ OMAN API is running",
        "docs": "/api/docs",
    }

# RESQ OMAN — Backend API

Production-oriented FastAPI backend for the RESQ OMAN emergency search &
rescue command platform. This is Phase 2 of the build — it follows the
Phase 1 frontend prototype (`resq-oman.html`) and implements the schema,
authentication, and core APIs that prototype's mock data was modeled on.

## Stack

- **FastAPI** — REST API, auto-generated OpenAPI/Swagger docs
- **PostgreSQL + SQLAlchemy 2.0** — data layer
- **Alembic** — versioned schema migrations
- **JWT (access + refresh tokens)** — authentication, via `python-jose`
- **Passlib/bcrypt** — password hashing
- **slowapi** — rate limiting

## Project layout

```
app/
  core/          settings, JWT + password hashing, logging
  db/            SQLAlchemy engine/session, declarative base
  models/        ORM models — one file per entity
  schemas/       Pydantic request/response models
  api/v1/        route handlers, grouped by resource
  middleware/    rate limiting + global error handlers
  seed.py        demo data matching the frontend prototype
  main.py        FastAPI app assembly (CORS, routers, error handlers, docs)
alembic/         migration environment (wired to app settings/models)
```

## Getting started

You'll need Python 3.12+ and a running PostgreSQL instance (local install,
or any managed Postgres — Supabase, Neon, RDS, etc.).

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env: set a real SECRET_KEY and DATABASE_URL pointing at your Postgres

uvicorn app.main:app --reload
```

- API: http://localhost:8000
- Swagger UI: http://localhost:8000/api/docs
- ReDoc: http://localhost:8000/api/redoc
- Health check: http://localhost:8000/api/health

Seed demo data (one user per role + sample missions/drones/vehicles, matching
the frontend mock data):

```bash
python -m app.seed
```

Demo login (after seeding): `commander@resq.om` / `ChangeMe123!` — change this
password immediately outside of a demo environment.

## Database migrations

The app calls `Base.metadata.create_all()` on startup for local/demo
convenience. For any real deployment, use Alembic instead:

```bash
alembic revision --autogenerate -m "initial schema"
alembic upgrade head
```

## Authentication flow

1. `POST /api/v1/auth/register` — create an account (role: commander, admin,
   operator, volunteer, or medic)
2. `POST /api/v1/auth/login` — OAuth2 password flow, returns access + refresh
   JWTs
3. `POST /api/v1/auth/refresh` — exchange a refresh token for a new pair
4. `POST /api/v1/auth/forgot-password` / `POST /api/v1/auth/reset-password`
5. `GET /api/v1/auth/verify-email?token=...`

Protected routes expect `Authorization: Bearer <access_token>`. Role-gated
routes (e.g. creating missions, managing personnel) return `403` for roles
without permission — see `app/api/deps.py::require_roles`.

> Email delivery for verification/reset is stubbed (the token is generated
> and stored, but no email is sent). Wire up a provider such as SES,
> SendGrid, or Postmark in `app/api/v1/auth.py` before going live.

## API surface (v1)

| Resource     | Endpoints |
|---|---|
| Auth         | register, login, refresh, forgot/reset password, verify email |
| Users        | `GET /users/me`, `GET /users` (commander/admin, paginated) |
| Missions     | full CRUD, filter by `status`/`priority`, pagination |
| Personnel    | list (filter by category), create, update |
| Drones       | list, `PATCH /drones/{id}/telemetry` (for live telemetry uplinks) |
| Alerts       | list (filter by type/unread), create, mark as read |
| AI Detections| list, create (for the Vision Agent / inference service to post results) |

Every list endpoint returns a consistent paginated envelope:
```json
{ "items": [...], "total": 0, "page": 1, "page_size": 20, "pages": 0 }
```
Every error returns a consistent envelope: `{ "error": "...", "detail": "..." }`.

## Security notes

- Passwords are hashed with bcrypt (never stored in plaintext).
- JWTs are short-lived (30 min access / 7 day refresh by default —
  configurable via `.env`).
- Rate limiting is applied via slowapi (`RATE_LIMIT_DEFAULT` in `.env`).
- CORS origins are explicit and env-configured, not wildcarded.
- No secrets are hardcoded — `SECRET_KEY`, DB credentials, etc. all come
  from environment variables. Never commit a real `.env`.
- `SECRET_KEY` must be a long random value in any non-local environment:
  `python -c "import secrets; print(secrets.token_urlsafe(64))"`

## What's still mocked / next steps

- **Email delivery** (verification, password reset) — currently generates
  tokens but doesn't send anything.
- **Real AI inference** — the `/detections` endpoint stores whatever the
  Vision Agent / model server posts to it; the actual model integration
  (drone feed ingestion, image/video inference) is not included here.
- **Real-time updates** — the frontend prototype's live feel (radar sweep,
  live alerts) is currently static/mock. Wire up WebSockets or Server-Sent
  Events on top of these same models for live push updates.
- **Mapbox** — the frontend prototype uses a stylized custom map; swapping
  in real Mapbox GL JS with a token, plus serving `lat`/`lng` already
  present on `Mission`, `Vehicle`, and `Drone` models, is the next step.
- **Refresh token revocation** — refresh tokens are stateless JWTs; for
  production, consider a server-side revocation list (e.g. Redis) so a
  compromised refresh token can be invalidated before it expires.
